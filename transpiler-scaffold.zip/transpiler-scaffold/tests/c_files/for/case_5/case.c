#include <stdio.h>

int main()
{
    int y;
    for (int x = 10; y = x - 3; x--)
    {
        printf("%d\n", y);
    } 

	return 0;
}
