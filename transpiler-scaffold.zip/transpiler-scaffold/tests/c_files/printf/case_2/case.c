#include <stdio.h>

int main()
{
    float x = 5.0;
    printf("%f\n", x);

	return 0;
}
