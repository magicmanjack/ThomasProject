#include <stdio.h>

int main()
{
    char c = 'a';
    printf("%c\n", c);

	return 0;
}
