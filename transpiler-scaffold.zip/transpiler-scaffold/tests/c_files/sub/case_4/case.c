#include <stdio.h>

int main()
{
    int x = 20;
    int y = -(6);

    printf("%d\n", x - y);

    return 0;
}