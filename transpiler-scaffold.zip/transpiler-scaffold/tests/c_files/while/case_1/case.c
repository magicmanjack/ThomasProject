#include <stdio.h>

int main()
{
    int x = 0;
    while (x < 7)
    {
        printf("Hello\n");
        x += 1;
    } 
    
    return 0;
}
