#include <stdio.h>

int main()
{
    int x = 0;
    for (int x = 0; x < 7; x++)
    {

        int y = 0;

        for (int y = 10; y < 2; y++)
        {

            printf("Hello\n");

        }

        x += 1;
    } 

	return 0;
}
