#include <stdio.h>

int main()
{
    int x = 5;
    
    scanf("%d\n", &x);

    printf("%d\n", x);

    return 0;
}
