#include <stdio.h>

int main()
{
    char c = 'a';

    scanf("%c\n", &c);

    printf("%c\n", c);

	return 0;
}
