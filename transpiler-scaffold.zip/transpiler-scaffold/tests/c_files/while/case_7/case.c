#include <stdio.h>

int main()
{
    int x = 0;
    while (x < 7)
        x++;
        printf("%d\n", x);


	return 0;
}
