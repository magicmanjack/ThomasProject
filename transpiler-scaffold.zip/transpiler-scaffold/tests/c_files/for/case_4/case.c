#include <stdio.h>

int main()
{
    for (int x = 10; x > 0; --x)
    {
        printf("%d\n", x);
    } 

	return 0;
}
