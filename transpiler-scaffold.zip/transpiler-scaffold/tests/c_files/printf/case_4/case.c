#include <stdio.h>

int main()
{
    char* c = "Hello World!";

    printf("%s\n", c);

    return 0;
}