#include <stdio.h>

int main()
{
    int x = 10;
    while (x--)
    {
        printf("%d\n", x);
    } 

	return 0;
}
