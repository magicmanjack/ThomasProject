#include <stdio.h>

int main()
{
    int x = 0;
    do
    {
        printf("Hello\n");
        x += 1;
    } while (x < 3);
    
    return 0;
}
