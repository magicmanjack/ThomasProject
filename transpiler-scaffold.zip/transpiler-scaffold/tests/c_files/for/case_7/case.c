#include <stdio.h>

int main()
{
    for (int x = 0; x < 8; x++)
        printf("%d\n", x);

	return 0;
}
