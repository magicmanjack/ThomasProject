#include <stdio.h>

int main()
{
    printf("Hello!\n");

    for (;;)
        return 0;

    printf("Hello!\n");
}
