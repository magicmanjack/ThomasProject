#include <stdio.h>

int main()
{
	int x =		5;
    int y =  6;

    int z  =   (x + y);

    printf("%d\n", z);

	return 0;
}
