#include <stdio.h>

int main()
{
    int x = 0;
    for (int x = 0; x < 7; x++)
    {
        printf("Hello\n");
        x += 1;
    } 
    
    return 0;
}
