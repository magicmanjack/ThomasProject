#include <stdio.h>

int main()
{

    printf("%d\n", 6 + 8);

	return 0;
}
