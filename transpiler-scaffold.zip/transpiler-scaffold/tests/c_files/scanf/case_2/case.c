#include <stdio.h>

int main()
{
    float x = 5.0;

    scanf("%f\n", &x);

    printf("%f\n", x);

	return 0;
}
