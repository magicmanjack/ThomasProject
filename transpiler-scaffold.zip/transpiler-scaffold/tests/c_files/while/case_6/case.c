#include <stdio.h>

int main()
{
    int x = 0;
    while (x < 2)
    {
        printf("%d\n", x);
        x++;
    } 

    while (x < 4) {
        printf("%d\n", x);
        x++;
    } 

    while (x < 6){
        printf("%d\n", x);
        x++;
    } 

    while (x < 8)	{
        printf("%d\n", x);
        x++;
    } 

    while(x < 10) {
        printf("%d\n", x);
        x++;
    } 

    while(x < 12){
        printf("%d\n", x);
        x++;
    } 

    while(x < 14)   {
        printf("%d\n", x);
        x++;
    } 

    while
        (x < 16)
    {
        printf("%d\n", x);
        x++;
    }

	return 0;
}
