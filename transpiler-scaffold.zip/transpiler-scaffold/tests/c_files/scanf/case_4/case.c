#include <stdio.h>

int main()
{
    char x[10];
    scanf("%9s\n", x);

    printf("%s", x);

    return 0;
}