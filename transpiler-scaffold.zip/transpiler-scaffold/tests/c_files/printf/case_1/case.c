#include <stdio.h>

int main()
{
    int x = 5;
    printf("%d\n", x);

    return 0;
}
